package mediaRentalManager;

/**
 * Album extends from the Media class  as it inherits certain attributes from the Media Class.
 * 
 * @author jessymanuella
 *
 */

public class Album extends Media {

	private String artists;
	private String songs;
/**
 * This methods calls the instance of artists and songs and access the superclass(Media) constructor.
 * 
 * @param title
 * @param copiesAvailable
 * @param artist
 * @param songs
 */
	public Album(String title, int copiesAvailable, String artist, String songs) {
		super(title, copiesAvailable);
		this.artists = artist;
		this.songs = songs;

	}
	/**
	 * This method returns artists.
	 * @return
	 */

	public String getArtist() {
		return artists;
	}
	/**
	 * This method returns the songs.
	 * @return
	 */

	public String getSong() {
		return songs;
	}
	/**
	 * This methods allows the string representation of the object. It will allow you to print the Artist and songs name.
	 */

	public String toString() {
		return super.toString() + ", Artist: " + this.artists + ", Songs: " + this.songs;
	}

}
