package mediaRentalManager;

/**
 * Movie extends from the Media class  as it inherits certain attributes from the Media Class.
 * @author jessymanuella
 *
 */

public class Movie extends Media {

	private String rating;

	/**
	 * This methods calls the instance of rating and access the superclass(Media) constructor.
	 * @param title
	 * @param copiesAvailable
	 * @param rating
	 */
	public Movie(String title, int copiesAvailable, String rating) {
		super(title, copiesAvailable);
		this.rating = rating;

	}
	/**
	 * This method returns the rating.
	 * @return
	 */

	public String getRating() {
		return rating;
	}
	/**
	 * This methods allows the string representation of the object. It will allow you to print the rating of the movie..
	 */

	public String toString() {
		return super.toString() + ", Rating: " + this.rating;
	}

}
