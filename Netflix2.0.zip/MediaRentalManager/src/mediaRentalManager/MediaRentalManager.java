package mediaRentalManager;

import java.util.ArrayList;
import java.util.Collections;

public class MediaRentalManager {

	private int value;
	private ArrayList<Customer> customers = new ArrayList<Customer>();
	private ArrayList<Media> media = new ArrayList<Media>();

	public MediaRentalManager() {
		this.value = 2;
	}

	public void addCustomer(String name, String address, String plan) {
		Customer customer = new Customer(name, address, plan);
		customers.add(customer);
	}

	public void addMovie(String title, int copiesAvailable, String rating) {
		Movie movie = new Movie(title, copiesAvailable, rating);
		media.add(movie);
	}

	public void addAlbum(String title, int copiesAvailable, String artist, 
			String songs) {
		Album album = new Album(title, copiesAvailable, artist, songs);
		media.add(album);
	}

	public void setLimitedPlanLimit(int value) {
		this.value = value;
	}

	public String getAllCustomersInfo() {
		Collections.sort(customers);
		String answer = "***** Customers' Information *****\n";
		for (Customer c : customers) {
			answer += c.toString();
		}

		return answer;
	}

	public String getAllMediaInfo() {
		Collections.sort(media);
		String answer = "***** Media Information *****";
		for (Media m : media) {
			answer += m.toString();
		}

		return answer;
	}

	public boolean addToQueue(String customerName, String mediaTitle) {
		for (Customer c : customers) {
			if (c.getName().equals(customerName)) {
				if (c.isInQueue(mediaTitle)) {
					return false;
				} else {
					c.addMediaTitle(mediaTitle);
					return true;
				}
			}
		}
		return false;
	}

	public boolean removeFromQueue(String customerName, String mediaTitle) {
		Customer temporaryCustomer = null;
		for (Customer c : customers) {
			if (c.getName().equals(customerName)) {
				temporaryCustomer = c;
			}
		}
		if (temporaryCustomer == null) {
			return false;
		} else {
			temporaryCustomer.removeMediaTitle(mediaTitle);
			return true;
		}
	}

	public String processRequests() {
		Collections.sort(customers);
		// System.out.print("We have process request");
		String answer = "";
		for (Customer c : customers) {
			ArrayList<String> copyQueue = new ArrayList<String>(c.getQueue());
			for (String entry : copyQueue) {
				if (c.getPlan().equals("UNLIMITED")) {
					// System.out.println("Got unlimited");
					for (Media m : media) {
						if (m.getTitle().equals(entry)) {
							if (m.getCopiesAvailable() > 0) {
								m.setUpdateCopies(-1);
								removeFromQueue(c.getName(), entry);
								c.addToRented(entry);
								answer += "Sending " + entry + " to " + 
								c.getName() + "\n";
								break;

							}

						}
					}

				} else if (c.getPlan().equals("LIMITED")) {
					/*
					 * System.out.println("Got limited"); System.out.println(c.getRented().size());
					 * System.out.println(this.value); System.out.println(c.getQueue().size());
					 * System.out.println(media.size());
					 */
					if (c.getRented().size() < this.value) {
						for (Media m : media) {
							if (m.getTitle().equals(entry)) {
								// System.out.println(m.getCopiesAvailable());
								if (m.getCopiesAvailable() > 0) {
									m.setUpdateCopies(-1);
									removeFromQueue(c.getName(), entry);
									c.addToRented(entry);
									answer += "Sending " + entry + " to " + 
									c.getName() + "\n";
									break;

								}

							}
						}
					}

				}
			}

		}
		// System.out.print(answer);

		return answer;
	}

	public boolean returnMedia(String customerName, String mediaTitle) {
		for (Customer c : customers) {
			if (customerName.equals(c.getName())) {
				if (c.isRented(mediaTitle)) {
					c.removeRented(mediaTitle);
					for (Media m : media) {
						if (m.getTitle().equals(mediaTitle)) {
							m.setUpdateCopies(1);
							break;
						}

					}
					return true;
				}

			}
		}
		return false;
	}

	public ArrayList<String> searchMedia(String title, String rating, 
			String artist, String songs) {
		ArrayList<String> tempMedia = new ArrayList<String>();
		for (Media m : media) {
			if (title == null && rating == null && artist == null && songs 
					== null) {
				tempMedia.add(m.getTitle());
			}
			if (title != null && title.equals(m.getTitle())) {
				tempMedia.add(m.getTitle());
			}

			if (rating != null && m instanceof Movie && rating.equals(((Movie) 
					m).getRating())) {
				tempMedia.add(m.getTitle());
			}

			if (artist != null && m instanceof Album && artist.equals(((Album) 
					m).getArtist())) {
				tempMedia.add(m.getTitle());
			}

			if (songs != null && m instanceof Album && 
					((Album) m).getSong().contains(songs)) {
				tempMedia.add(m.getTitle());
			}

		}
		Collections.sort(tempMedia);
		return tempMedia;
	}

}
